function go1()
{
prompt()
}